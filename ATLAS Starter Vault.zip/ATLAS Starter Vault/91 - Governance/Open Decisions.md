---
type: governance
status: open
---

# Open Decisions

Everything below is **OPEN**. Do not treat any as resolved. When one is resolved, move it to [[Resolved Decisions]] and record it in [[Change Log]].

## Experience / Epistemic Boundary (central thread — see [[Experience Boundary]])
- [ ] Exact definition of Experience
- [ ] Immediate capture versus interpretation
- [ ] Experience → Learning transition
- [ ] Learning → Knowledge promotion
- [ ] Knowledge → Capability promotion
- [ ] Capability → Authorized Behavior authorization

## Authority
- [ ] Authority source
- [ ] Validation authority
- [ ] Promotion authority
- [ ] Conflict resolution

## Distributed Governance
- [ ] Consensus requirements
- [ ] Voting participation
- [ ] Voting weight
- [ ] Unavailable Nodes
- [ ] Escalation

## Architecture
- [ ] LIOS ↔ ATLAS ↔ STAIR-G interfaces ([[LIOS Interface]], [[STAIR-G Interface]])
- [ ] Hermes implementation mapping ([[Hermes Interface]])
- [ ] Hub / Living Hub terminology (intentionally unresolved; see [[Current Architecture]])

## ATLAS Ontology ([[ATLAS Ontology]])
- [ ] Exact item states
- [ ] Status transitions
- [ ] Evidence thresholds
- [ ] Uncertainty representation
- [ ] Contradiction representation
- [ ] Supersession
