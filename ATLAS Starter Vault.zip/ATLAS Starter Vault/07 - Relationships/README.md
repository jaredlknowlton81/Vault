---
type: folder-readme
status: working
---

# Relationships

Typed links between items (derived-from, supersedes, contradicts, supports, etc.). Whether these are separate files is an OPEN ontology question.

No template defined yet.

See [[ATLAS Ontology]] and [[Promotion Rules]].
