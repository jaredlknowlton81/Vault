---
type: decisions
status: working
---

# Resolved Decisions

- LIOS is the overarching architecture.
- Vault ≠ ATLAS.
- A standalone ATLAS Starter Vault is an intended architectural artifact.
- ATLAS LINT inspects existing ATLAS only.
- ATLAS LINT does not create new Knowledge.
- Deterministic LINT findings may be auto-fixed and logged.
- Interpretive LINT findings are flagged for review.
- Node ≠ device.
- Devices are access / implementation mechanisms rather than necessarily the Node itself.
- Hub = coordinated Nodes is the current *working* concept (Hub vs Living Hub distinction remains OPEN).
- STAIR-G's governed loop is established conceptually.
- LIOS distinctions among capability, governance, learning, and transcendence are established.

Unresolved items live in [[Open Decisions]].
