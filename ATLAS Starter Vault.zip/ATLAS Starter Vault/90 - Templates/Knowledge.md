---
type: knowledge
status: proposed
id: 
derived_from: 
evidence: 
validated_by: 
validation_date: 
authority: 
uncertainty: 
contradicts: 
supersedes: 
---

# Knowledge

## Claim

## Conditions / Boundaries

## Supporting Evidence

## Validation

## Uncertainty

## Conflicts / Alternatives

## Lineage
