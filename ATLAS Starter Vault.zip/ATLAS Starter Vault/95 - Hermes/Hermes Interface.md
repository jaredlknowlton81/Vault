---
type: interface
status: working
mapping: OPEN
---

# Hermes Interface

## Working distinction
- **Hermes** = implementation pattern
- **STAIR-G** = governed improvement mechanism
- **LIOS** = overarching capability/governance architecture

Do not alter the conceptual LIOS / STAIR-G boundaries merely to fit an implementation.

## Mapping Hermes components to
Each is **OPEN** — to be filled in only once the mapping is actually determined.

| Concern | Hermes component | Status |
|---|---|---|
| Agent orchestration | | OPEN |
| Tools / actions | | OPEN |
| Observations | | OPEN |
| Persistent memory | | OPEN |
| Knowledge / documentation | | OPEN |
| Validation | | OPEN |
| Adaptation | | OPEN |
| Governance | | OPEN |

Related: [[STAIR-G Interface]], [[LIOS Interface]], [[Open Decisions]].
