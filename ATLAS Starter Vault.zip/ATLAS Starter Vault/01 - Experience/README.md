---
type: folder-readme
status: working
---

# Experience

What happened or was observed. Preserve evidence; do not silently embed interpretation.

Template: [[Experience]]

See [[ATLAS Ontology]] and [[Promotion Rules]].
