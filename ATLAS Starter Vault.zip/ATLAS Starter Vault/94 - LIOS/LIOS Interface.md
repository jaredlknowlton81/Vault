---
type: interface
status: working
---

# LIOS Interface

LIOS is the overarching capability/governance architecture.

## LIOS recursion
Failure → Constraint → Capability → Governance → Observation → Learning → Adaptation → Transcendence → New Capability Space → New Governance Requirements → Repeat

ATLAS provides structured evidence and epistemic lineage for this recursion.

## OPEN
- Exact LIOS ↔ ATLAS boundary
- Representation of Transcendence
- Governance reconfiguration triggers
- How ATLAS exposes evidence to LIOS

Related: [[Current Architecture]], [[STAIR-G Interface]], [[Open Decisions]].
