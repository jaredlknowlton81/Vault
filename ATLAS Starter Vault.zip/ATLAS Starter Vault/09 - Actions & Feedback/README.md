---
type: folder-readme
status: working
---

# Actions & Feedback

Actions taken and Feedback received. No template yet; the representation of Feedback is OPEN (see STAIR-G Interface).

No template defined yet.

See [[ATLAS Ontology]] and [[Promotion Rules]].
