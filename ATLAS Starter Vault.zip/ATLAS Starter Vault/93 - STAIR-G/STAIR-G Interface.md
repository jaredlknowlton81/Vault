---
type: interface
status: working
---

# STAIR-G Interface

## Loop
Reason → Act → Observe → Evaluate → Learn → Propose → Validate → Adapt → Repeat

## Working relationship with ATLAS
- ATLAS provides durable epistemic state.
- STAIR-G evaluates Experience.
- STAIR-G generates Learning.
- STAIR-G proposes changes.
- STAIR-G validates proposals.
- STAIR-G adapts behavior.

## Critical boundary
STAIR-G does not allow Experience to automatically become trusted Capability.

## OPEN
- Input/output contracts
- Promotion triggers
- Validation mechanism
- Authority interaction
- Feedback representation
- Rejection handling
- Uncertainty handling

Related: [[Promotion Rules]], [[Open Decisions]], [[LIOS Interface]], [[Hermes Interface]].
