---
type: ledger-event
status: recorded
id: 
timestamp: 
event_kind: 
actor: 
related_items: 
authority: 
result: 
evidence: 
---

# Ledger Event

## Event

## Context

## Result

## Evidence

## Related Items
