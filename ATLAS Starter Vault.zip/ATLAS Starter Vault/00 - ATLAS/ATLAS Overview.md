---
type: meta
status: working
---

# ATLAS Overview

ATLAS is the structured memory / state layer. It preserves:
- what happened (Experience),
- what was learned from it (Learning),
- what became trusted knowledge (Knowledge),
- what became capability (Capability),
- and what governance authorized (Authorized Behavior)

without allowing those states to collapse into one another.

## Loop position
EXPERIENCE → ATLAS (memory/state) → ATLAS LINT (integrity) → STAIR-G (evaluate/learn/propose/validate) → AUTHORITY / GOVERNANCE → CAPABILITY / AUTHORIZATION → ACTION / OUTCOME → back to EXPERIENCE.

See [[Current Architecture]], [[ATLAS LINT]], [[STAIR-G Interface]], [[LIOS Interface]], [[Hermes Interface]].

## Invariants
1. Experience is evidence.
2. Interpretation may evolve.
3. Learning is not automatically Knowledge.
4. Knowledge is not automatically Capability.
5. Capability is not automatically Authorization.
6. Storage does not equal trust.
7. No experience should automatically become trusted capability.
8. Historical provenance should remain traceable.
9. Contradiction should be represented, not silently erased.
10. Governance should be able to adapt when capability changes.

## Central open thread
The highest-leverage unresolved question: *What is the precise boundary between Experience, Learning, Knowledge, Capability, and trusted/authorized behavior?* See [[Experience Boundary]] and [[Open Decisions]].
