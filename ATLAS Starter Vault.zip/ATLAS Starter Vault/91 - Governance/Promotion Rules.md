---
type: governance
status: open
---

# Promotion Rules

> Promotion rules are intentionally **OPEN**. Core constraint: **Storage does not equal trust.**

For each transition below, eventually define:
1. Evidence requirements
2. Validation requirements
3. Authority requirements
4. Uncertainty handling
5. Conflict handling
6. Reversibility / supersession
7. Audit / provenance requirements

## Experience → Learning
All seven: **OPEN**

## Learning → Knowledge
All seven: **OPEN**

## Knowledge → Capability
All seven: **OPEN**

## Capability → Authorized Behavior
All seven: **OPEN**

Related: [[Open Decisions]], [[Experience Boundary]], [[STAIR-G Interface]].
