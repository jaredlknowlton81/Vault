---
type: folder-readme
status: working
---

# Entities

Nodes, actors, authorities, and other entities. Node ≠ device.

Template: [[Entity]]

See [[ATLAS Ontology]] and [[Promotion Rules]].
