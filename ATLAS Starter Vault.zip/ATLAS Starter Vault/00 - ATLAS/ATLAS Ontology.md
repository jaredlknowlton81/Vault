---
type: meta
status: working
ontology: OPEN
---

# ATLAS Ontology

> The ontology is **OPEN**. Nothing here is final.

## Conceptual item types (initial)
Experience · Learning · Knowledge · Capability · Authorized Behavior · Entity · Relationship · Ledger Event · Action · Feedback

**OPEN:** These need not ultimately be separate file types.

## Candidate statuses (not finalized)
Observed · Interpreted · Learning · Proposed · Validated · Trusted · Operational · Authorized · Superseded · Rejected · Uncertain

**OPEN:** exact state model, status transitions, evidence thresholds.

## Provenance
Every item should be able to answer:
- Where did this come from?
- When did it originate?
- What Node produced or observed it?
- Under what conditions?
- What evidence supports it?
- What previous item did it derive from?
- What later item superseded or transformed it?
- What capability or action resulted?

Example lineage: E-001 → L-014 → K-007 → C-003 → AB-002 → A-019 → O-019 → E-019.
(Illustrative IDs only.)

## Uncertainty
First-class information. Must be representable: uncertainty, confidence, incomplete evidence, competing interpretations, contradictory evidence, unresolved questions, superseded knowledge. **OPEN:** no final uncertainty model.

## Contradiction
Contradiction must not destroy history. If K-019 conflicts with K-007, K-007 is retained and the relationship recorded (e.g. K-007 *superseded by* K-019). Do not silently rewrite historical Knowledge. **OPEN:** contradiction representation and supersession mechanics.

Related: [[Open Decisions]], [[Promotion Rules]].
