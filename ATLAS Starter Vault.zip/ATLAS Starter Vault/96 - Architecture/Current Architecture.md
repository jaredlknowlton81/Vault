---
type: architecture
status: working
---

# Current Architecture

```
EXPERIENCE
    ▼
ATLAS  (memory / state)
    ▼
ATLAS LINT  (integrity)
    ▼
STAIR-G  (evaluate / learn / propose / validate)
    ▼
AUTHORITY / GOVERNANCE
    ▼
CAPABILITY / AUTHORIZATION
    ▼
ACTION / OUTCOME
    └──────────► EXPERIENCE
```
The loop closes through Experience.

## Components
[[ATLAS Overview]] · [[ATLAS LINT]] · [[STAIR-G Interface]] · [[LIOS Interface]] · [[Hermes Interface]]

## Hub / Living Hub — intentionally OPEN
Current working concept: **Hub = a coordinated collective of Nodes.** Hub and Living Hub may refer to the same underlying thing. The distinction is unresolved; no final ontology for Hub vs Living Hub is created here.

Related: [[Open Decisions]], [[Resolved Decisions]].
