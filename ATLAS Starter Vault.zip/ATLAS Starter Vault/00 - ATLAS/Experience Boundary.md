---
type: meta
status: open
thread: central
---

# Experience Boundary

## Working principle
**Experience is preserved as evidence; interpretation is allowed to evolve.**

The original record of what happened must remain distinguishable from later interpretations of it.

## Experience may include
Actions · Observations · Outcomes · Failures · Interactions · Environmental changes · Decisions · Conditions · Context · Evidence

## Distinctions
- Experience ≠ Learning — an observation can exist without a valid interpretation.
- Learning ≠ Knowledge — a hypothesis can be useful without sufficient validation.
- Knowledge ≠ Capability — knowing does not mean the system can operationalize it.
- Capability ≠ Authorization — able to do something is not permission to do it.

Do not assume every Experience becomes Learning, or every Learning becomes Knowledge.

## OPEN THREAD — Highest-leverage question
What is the precise boundary between Experience, Learning, Knowledge, Capability, and trusted/authorized behavior?

Resolving it should clarify the relationships among LIOS, ATLAS, ATLAS LINT, STAIR-G, Authority, Governance, Capability, and Authorization.

Sub-questions (all OPEN, tracked in [[Open Decisions]]):
- Exact definition of Experience
- Immediate capture versus interpretation
- Experience → Learning transition
- Learning → Knowledge promotion
- Knowledge → Capability promotion
- Capability → Authorized Behavior authorization

See [[Promotion Rules]].
