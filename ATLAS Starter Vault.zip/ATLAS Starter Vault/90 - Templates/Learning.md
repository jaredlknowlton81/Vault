---
type: learning
status: learning
id: 
derived_from: 
proposed_by: 
evidence: 
uncertainty: 
contradicts: 
supports: 
---

# Learning

## Interpretation / Lesson

## What Does the Experience Appear to Mean?

## Evidence

## Uncertainty

## Conflicting Interpretations

## Promotion Proposal
