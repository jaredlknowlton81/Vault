---
type: 
status: 
id: 
timestamp: 
node: 
derived_from: 
evidence: 
uncertainty: 
supersedes: 
superseded_by: 
contradicts: 
related: 
---

# ATLAS Item

> Generic base template. Note: the build spec lists this file but does not define its contents; the fields above are a minimal provenance/uncertainty/supersession skeleton drawn from the Provenance, Uncertainty, and Contradictions sections. Treat as provisional.

## Summary

## Provenance

## Evidence

## Uncertainty

## Related
