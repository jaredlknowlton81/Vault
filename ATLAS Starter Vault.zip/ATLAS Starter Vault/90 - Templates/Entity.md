---
type: entity
status: active
id: 
entity_kind: 
name: 
node: 
authority: 
relationships: 
---

# Entity
