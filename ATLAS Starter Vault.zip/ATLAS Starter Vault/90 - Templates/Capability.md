---
type: capability
status: proposed
id: 
derived_from: 
knowledge: 
owner: 
boundaries: 
dependencies: 
performance: 
failure_modes: 
governance: 
authorization: 
---

# Capability

## What Can the System Do?

## Preconditions

## Performance Specification

## Boundaries

## Dependencies

## Failure Modes

## Governance

## Authorization

## Knowledge Lineage
