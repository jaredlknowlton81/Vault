---
type: folder-readme
status: working
---

# Authorized Behavior

A Capability that governance has explicitly permitted within a defined scope and context.

Template: [[Authorized Behavior]]

See [[ATLAS Ontology]] and [[Promotion Rules]].
