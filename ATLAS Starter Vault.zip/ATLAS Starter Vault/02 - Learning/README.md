---
type: folder-readme
status: working
---

# Learning

Interpretations, patterns, hypotheses, or reusable lessons derived from Experience. Not automatically Knowledge.

Template: [[Learning]]

See [[ATLAS Ontology]] and [[Promotion Rules]].
