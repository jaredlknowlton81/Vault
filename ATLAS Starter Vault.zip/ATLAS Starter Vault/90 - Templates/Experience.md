---
type: experience
status: observed
id: 
timestamp: 
source: 
node: 
context: 
action: 
observation: 
outcome: 
evidence: 
uncertainty: 
related: 
---

# Experience

## What Happened?

## Observation

## Outcome

## Evidence

## Context

## Uncertainty

## Related Lineage
