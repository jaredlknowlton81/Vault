---
type: readme
status: working
version: 0.1
---

# ATLAS Starter Vault

**Version 0.1 — Working / Starter Architecture**

ATLAS is the structured memory / knowledge layer within the broader LIOS architecture. This vault is a starter scaffold for continued architectural development. It is intentionally incomplete: items marked **OPEN** are open threads, not hidden answers.

## Core principle
- Storage does not equal trust.
- Accumulation does not equal validation.
- Experience ≠ Knowledge ≠ Capability ≠ Authorization.
- No experience should automatically become trusted capability.

## Epistemic progression
Experience → Learning → Knowledge → Capability → Authorized Behavior

## Start here
- [[ATLAS Overview]]
- [[ATLAS Ontology]]
- [[Experience Boundary]]
- [[Open Decisions]]
- [[Resolved Decisions]]
- [[Promotion Rules]]
- [[Current Architecture]]
- [[ATLAS Index]]

## Folders
00 ATLAS · 01 Experience · 02 Learning · 03 Knowledge · 04 Capability · 05 Authorized Behavior · 06 Entities · 07 Relationships · 08 Ledger · 09 Actions & Feedback · 90 Templates · 91 Governance · 92 LINT · 93 STAIR-G · 94 LIOS · 95 Hermes · 96 Architecture · 97 Decisions · 98 Registers · 99 Index
