---
type: folder-readme
status: working
---

# Capability

Knowledge operationalized into something the system can do. Capability ≠ Authorization.

Template: [[Capability]]

See [[ATLAS Ontology]] and [[Promotion Rules]].
