---
type: folder-readme
status: working
---

# Ledger

Ledger Events: recorded events with actor, authority, result, and evidence.

Template: [[Ledger Event]]

See [[ATLAS Ontology]] and [[Promotion Rules]].
