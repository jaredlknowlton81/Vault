---
type: lint-spec
status: working
---

# ATLAS LINT

**Purpose:** Protect ATLAS integrity.

**Boundary:** Inspect existing ATLAS only. No accumulation / no new Knowledge.

## Inspects
- Links
- Frontmatter
- Duplicates
- Orphans
- Near-duplicates
- Contradictions
- Stale Knowledge
- Ledger references
- Stalled Actions

## Decision mode
- **Deterministic** → Auto-fix → Verify → Log
- **Interpretive** → Flag → Human Review

## LINT must NOT
- create Knowledge
- promote Learning
- authorize Capability
- resolve substantive disagreement
- change governance rules

LINT protects structural integrity. It does not independently determine substantive truth.

Related: [[Resolved Decisions]], [[Change Log]], [[Current Architecture]].
