---
type: folder-readme
status: working
---

# Knowledge

Learning that has satisfied evidence and validation requirements. Requirements for promotion are OPEN. Superseded items are preserved, not rewritten.

Template: [[Knowledge]]

See [[ATLAS Ontology]] and [[Promotion Rules]].
