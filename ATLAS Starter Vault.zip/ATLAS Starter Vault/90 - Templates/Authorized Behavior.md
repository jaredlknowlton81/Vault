---
type: authorized-behavior
status: proposed
id: 
capability: 
authority: 
scope: 
conditions: 
limits: 
effective: 
expires: 
review: 
---

# Authorized Behavior

## Authorized Capability

## Scope

## Conditions

## Limits

## Authority

## Review / Expiration

## Evidence and Lineage
